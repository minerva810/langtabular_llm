import json
import random
from pathlib import Path

import pandas as pd


BASE = Path(__file__).resolve().parents[1]

OUT_TABLE_DIR = BASE / "dataset" / "tables" / "controlled_synthetic"
OUT_META = BASE / "dataset" / "metadata" / "controlled_synthetic_metadata.jsonl"
OUT_Q = BASE / "dataset" / "questions" / "controlled_synthetic_questions.jsonl"

RANDOM_SEED = 42
TABLES_PER_TYPE = 100
ROWS_PER_TABLE = 35


COUNTRIES = [
    ("Korea", "한국"),
    ("Japan", "일본"),
    ("China", "중국"),
    ("USA", "미국"),
    ("Germany", "독일"),
    ("France", "프랑스"),
    ("Canada", "캐나다"),
    ("Brazil", "브라질"),
    ("Vietnam", "베트남"),
    ("Switzerland", "스위스"),
    ("Spain", "스페인"),
    ("UK", "영국"),
    ("India", "인도"),
    ("Taiwan", "대만"),
    ("Italy", "이탈리아"),
]

CITIES = [
    ("Seoul", "서울"),
    ("Tokyo", "도쿄"),
    ("Berlin", "베를린"),
    ("Paris", "파리"),
    ("Toronto", "토론토"),
    ("Busan", "부산"),
    ("Osaka", "오사카"),
    ("Chicago", "시카고"),
]

PRODUCTS = [
    ("Laptop", "노트북"),
    ("Tablet", "태블릿"),
    ("Camera", "카메라"),
    ("Monitor", "모니터"),
    ("Keyboard", "키보드"),
    ("Speaker", "스피커"),
    ("Printer", "프린터"),
    ("Router", "공유기"),
]

REGIONS = [
    ("North", "북부"),
    ("South", "남부"),
    ("East", "동부"),
    ("West", "서부"),
    ("Central", "중부"),
]

STATUS = [
    ("Active", "활성"),
    ("Delayed", "지연"),
    ("Paused", "중단"),
    ("Completed", "완료"),
]


def save_jsonl(items, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def save_pair(table_id, df_en, df_ko, data_type):
    table_dir = OUT_TABLE_DIR / data_type
    table_dir.mkdir(parents=True, exist_ok=True)

    en_path = table_dir / f"{table_id}_en.csv"
    ko_path = table_dir / f"{table_id}_ko.csv"

    df_en.to_csv(en_path, index=False, encoding="utf-8-sig")
    df_ko.to_csv(ko_path, index=False, encoding="utf-8-sig")

    return str(en_path), str(ko_path)


def make_question(table_id, idx, question, gold_answer, evidence, task_type, data_type, gold_answer_ko=None):
    item = {
        "question_id": f"{table_id}_q{idx}",
        "table_id": table_id,
        "question": question,
        "gold_answer": str(gold_answer),
        "evidence": evidence,
        "task_type": task_type,
        "data_type": data_type,
        "difficulty": "controlled",
    }
    if gold_answer_ko is not None:
        item["gold_answer_ko"] = str(gold_answer_ko)
    return item


def paired_value_map(pairs):
    return {en: ko for en, ko in pairs}


def make_unique_entities(pairs, n):
    en_values = []
    ko_values = []

    for idx in range(n):
        en, ko = pairs[idx % len(pairs)]
        suffix = idx + 1
        en_values.append(f"{en} {suffix}")
        ko_values.append(f"{ko} {suffix}")

    return en_values, ko_values


def build_numeric_table(table_idx):
    table_id = f"synthetic_numeric_{table_idx:03d}"
    rows = [f"Unit {table_idx}-{i}" for i in range(1, ROWS_PER_TABLE + 1)]

    base = 100 + table_idx * 3
    df_en = pd.DataFrame(
        {
            "Unit": rows,
            "Sales": [base + random.randint(10, 120) for _ in rows],
            "Cost": [base // 2 + random.randint(5, 80) for _ in rows],
            "Defect Rate": [round(random.uniform(0.5, 8.0), 2) for _ in rows],
        }
    )

    column_mapping = {
        "Unit": "단위",
        "Sales": "매출",
        "Cost": "비용",
        "Defect Rate": "불량률",
    }
    df_ko = df_en.rename(columns=column_mapping)

    max_sales_row = df_en.loc[df_en["Sales"].idxmax()]
    target_row = df_en.iloc[table_idx % len(df_en)]
    avg_defect = round(df_en["Defect Rate"].mean(), 2)

    questions = [
        make_question(
            table_id,
            1,
            f"What are the sales of {target_row['Unit']}?",
            target_row["Sales"],
            {"row": target_row["Unit"], "column": "Sales"},
            "retrieval",
            "numeric",
        ),
        make_question(
            table_id,
            2,
            "Which unit has the highest sales?",
            max_sales_row["Unit"],
            {"column": "Sales", "operation": "max"},
            "comparison",
            "numeric",
        ),
        make_question(
            table_id,
            3,
            "What is the average defect rate?",
            avg_defect,
            {"column": "Defect Rate", "operation": "average"},
            "aggregation",
            "numeric",
        ),
    ]

    return table_id, df_en, df_ko, column_mapping, questions


def build_text_table(table_idx):
    table_id = f"synthetic_text_{table_idx:03d}"
    city_en, city_ko = make_unique_entities(CITIES, ROWS_PER_TABLE)
    region_sample = random.choices(REGIONS, k=ROWS_PER_TABLE)
    status_sample = random.choices(STATUS, k=ROWS_PER_TABLE)

    df_en = pd.DataFrame(
        {
            "City": city_en,
            "Region": [region for region, _ in region_sample],
            "Project Status": [status for status, _ in status_sample],
            "Owner Team": [f"Team {chr(65 + (i % 26))}" for i in range(ROWS_PER_TABLE)],
        }
    )

    region_ko = paired_value_map(REGIONS)
    status_ko = paired_value_map(STATUS)

    column_mapping = {
        "City": "도시",
        "Region": "지역",
        "Project Status": "프로젝트 상태",
        "Owner Team": "담당 팀",
    }
    df_ko = pd.DataFrame(
        {
            "도시": city_ko,
            "지역": [region_ko[v] for v in df_en["Region"]],
            "프로젝트 상태": [status_ko[v] for v in df_en["Project Status"]],
            "담당 팀": list(df_en["Owner Team"]),
        }
    )

    target_row = df_en.iloc[table_idx % len(df_en)]
    target_row_ko = df_ko.iloc[table_idx % len(df_ko)]
    delayed = df_en[df_en["Project Status"] == "Delayed"]
    delayed_ko = df_ko[df_ko["프로젝트 상태"] == "지연"]
    delayed_answer = delayed.iloc[0]["City"] if not delayed.empty else "None"
    delayed_answer_ko = delayed_ko.iloc[0]["도시"] if not delayed_ko.empty else "None"

    questions = [
        make_question(
            table_id,
            1,
            f"What is the project status of {target_row['City']}?",
            target_row["Project Status"],
            {"row": target_row["City"], "column": "Project Status"},
            "retrieval",
            "text",
            gold_answer_ko=target_row_ko["프로젝트 상태"],
        ),
        make_question(
            table_id,
            2,
            "Which city has a delayed project?",
            delayed_answer,
            {"column": "Project Status", "condition": "Delayed"},
            "filtering",
            "text",
            gold_answer_ko=delayed_answer_ko,
        ),
        make_question(
            table_id,
            3,
            f"Which team owns the project in {target_row['City']}?",
            target_row["Owner Team"],
            {"row": target_row["City"], "column": "Owner Team"},
            "retrieval",
            "text",
        ),
    ]

    return table_id, df_en, df_ko, column_mapping, questions


def build_mixed_table(table_idx):
    table_id = f"synthetic_mixed_{table_idx:03d}"
    product_en, product_ko = make_unique_entities(PRODUCTS, ROWS_PER_TABLE)
    country_sample = random.choices(COUNTRIES, k=ROWS_PER_TABLE)

    df_en = pd.DataFrame(
        {
            "Product": product_en,
            "Country": [country for country, _ in country_sample],
            "Revenue": [random.randint(500, 5000) for _ in range(ROWS_PER_TABLE)],
            "Rating": [round(random.uniform(2.5, 5.0), 1) for _ in range(ROWS_PER_TABLE)],
        }
    )

    country_ko = paired_value_map(COUNTRIES)

    column_mapping = {
        "Product": "제품",
        "Country": "국가",
        "Revenue": "매출",
        "Rating": "평점",
    }
    df_ko = pd.DataFrame(
        {
            "제품": product_ko,
            "국가": [country_ko[v] for v in df_en["Country"]],
            "매출": list(df_en["Revenue"]),
            "평점": list(df_en["Rating"]),
        }
    )

    target_row = df_en.iloc[table_idx % len(df_en)]
    max_revenue_row = df_en.loc[df_en["Revenue"].idxmax()]
    max_revenue_row_ko = df_ko.loc[df_en["Revenue"].idxmax()]
    high_rating_count = int((df_en["Rating"] >= 4.0).sum())

    questions = [
        make_question(
            table_id,
            1,
            f"What is the revenue of {target_row['Product']}?",
            target_row["Revenue"],
            {"row": target_row["Product"], "column": "Revenue"},
            "retrieval",
            "mixed",
        ),
        make_question(
            table_id,
            2,
            "Which product has the highest revenue?",
            max_revenue_row["Product"],
            {"column": "Revenue", "operation": "max"},
            "comparison",
            "mixed",
            gold_answer_ko=max_revenue_row_ko["제품"],
        ),
        make_question(
            table_id,
            3,
            "How many products have a rating of at least 4.0?",
            high_rating_count,
            {"column": "Rating", "condition": ">= 4.0", "operation": "count"},
            "filtering",
            "mixed",
        ),
    ]

    return table_id, df_en, df_ko, column_mapping, questions


def add_metadata(metadata, table_id, en_path, ko_path, data_type, column_mapping):
    metadata.append(
        {
            "table_id": table_id,
            "split_type": "controlled_synthetic",
            "table_en_path": en_path,
            "table_ko_path": ko_path,
            "num_rows": ROWS_PER_TABLE,
            "num_cols": 4,
            "data_type": data_type,
            "difficulty": "controlled",
            "column_mapping": column_mapping,
            "paired_guarantee": True,
        }
    )


def main():
    random.seed(RANDOM_SEED)

    metadata = []
    questions = []

    builders = [
        ("numeric", build_numeric_table),
        ("text", build_text_table),
        ("mixed", build_mixed_table),
    ]

    for data_type, builder in builders:
        for idx in range(1, TABLES_PER_TYPE + 1):
            table_id, df_en, df_ko, column_mapping, table_questions = builder(idx)
            en_path, ko_path = save_pair(table_id, df_en, df_ko, data_type)
            add_metadata(metadata, table_id, en_path, ko_path, data_type, column_mapping)
            questions.extend(table_questions)

    save_jsonl(metadata, OUT_META)
    save_jsonl(questions, OUT_Q)

    print(f"[controlled_synthetic] tables: {len(metadata)}, questions: {len(questions)}")
    print("[data type distribution]")
    for data_type, _ in builders:
        count = sum(item["data_type"] == data_type for item in metadata)
        print(f"- {data_type}: {count}")


if __name__ == "__main__":
    main()
